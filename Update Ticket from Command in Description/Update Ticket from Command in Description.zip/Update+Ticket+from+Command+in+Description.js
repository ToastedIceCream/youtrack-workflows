statelessrule("Update Ticket from Command in Description", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "becomesReported", []);
}, function(ctx) {
  
  var syntaxStart = "__inDescCmdStart__";
  var syntaxEnd = "__inDescCmdEnd__";
  
  var index = strOp("indexOf", safeCall(ctx.issue,"get", ["description"], null), syntaxStart);
  if (!equals(index, -1)) {
    var value = strOp("substring", safeCall(ctx.issue,"get", ["description"], null), index + strOp("length", (syntaxStart)));
    index = strOp("indexOf", value, syntaxEnd);
    if (!equals(index, -1)) {
      value = strOp("substring", value, 0, index);
      if (strOp("isNotEmpty", value)) {
        invoke(ctx, ctx.issue, "applyCommand", [value]);
      }
    }
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "description", type: {name: "string", primitive: true}}]}]));